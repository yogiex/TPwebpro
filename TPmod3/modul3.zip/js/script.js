$(document).ready(function() {
    $("button.btn_0030").click(function() {
        alert("hai nama saya yogi NIM:1303170030")
    });
});